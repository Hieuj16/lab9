/*
 * @author: Hieu Tran
 */
public class SavingsAccount extends BankAccount {
	private double rate = 0.025;
	private int savings = 0;
	private String accountNumber;
	
	public SavingsAccount(String name, double balance) {
		super(name, balance);
		this.accountNumber = super.getAccountNumber() + "-" + savings; //set acc #
	}
	public SavingsAccount(SavingsAccount account, double balance) {
		super(account, balance);
		savings++;
		accountNumber = super.getAccountNumber() + "-" + savings; // set new acc #
	}
	public void postInterest() {
		double balance = getBalance();
		double interest = balance * (1 + (rate / 12)); // the interest calculation
		setBalance(interest);
	}
	public String getAccountNumber() {
		return accountNumber;
	}
}